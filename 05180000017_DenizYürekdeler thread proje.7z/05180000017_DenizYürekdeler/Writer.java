import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

public class Writer {
	
private String filepath;
private boolean append=false;

public Writer(String filepath,boolean append) {  // append değişkeni sayesinde, output metin belgesine sadece en son işlenen uyarı değil( update methodu)
	this.filepath=filepath;							// baştan sona tüm uyarıları alt alta yazdırabiliyor
	this.append=append;	
}
public void write(String text) throws IOException {
	FileWriter write = new FileWriter(filepath,append);
	PrintWriter print = new PrintWriter(write);
	print.println(text);
	print.close();
	
}


}
