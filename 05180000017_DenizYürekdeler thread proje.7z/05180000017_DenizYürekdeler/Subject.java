import java.util.ArrayList;


public class Subject {
	
	private ArrayList<Observer> observers = new ArrayList<Observer>();
	private int state;
	String companyname;
	
	
	public Subject(String companyname) {
		this.companyname=companyname;
	}
	
	
	public int getState() {
      return state;
   }
   
   public String getName() {
	   return companyname;
   }
   
   public void setName(String newname) {
	   companyname=newname;
   }

   public void setState(int state) {
      this.state = state;
     for(Observer o : observers) { //bu döngü ile firmanın her gözlemcisinin hangi firma olduğunu anlamasını sağlıyor
    	  o.setSubject(this);
      }
    		  
      notifyAllObservers();
   }
   
   public ArrayList<Observer> getList() {
	   return observers;
   }

   public void attach(Observer observer){ //gözlemciyi, gözlemciler listesine ekleme
	  observers.add(observer);
		  
   }
   
   public void notifyAllObservers(){  //tüm gözlemcilere uyarı gönderme
	   
     for(Observer o : observers) {
    	 o.update();
    	 
     }
   } 	
}