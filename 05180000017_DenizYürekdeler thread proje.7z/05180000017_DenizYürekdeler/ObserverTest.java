import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ObserverTest {
	 public static void main(String[] args) throws InterruptedException {
		 
		 Random rd = new Random();  // iş parçacıklarını uyutma amaçlı
	     
	      Subject B = new Subject("Company B"); // test amaçlı 5 firma açıldı
	      Subject A = new Subject("Company A");
	      Subject C = new Subject("Company C");
	      Subject D = new Subject("Company D");
	      Subject E = new Subject("Company E");
	      
	      ArrayList<Subject> companylist = new ArrayList<Subject>();  //kodu test etmek için bir firma öbeği oluşturuluyor
	      companylist.add(A);
	      companylist.add(B);
	      companylist.add(C);
	      companylist.add(D);
	      companylist.add(E);
	      
	      Observer multipleComObserver = new ShareObserver(companylist, "Observer1"); 	//çoklu firmalı gözlemci çağırımı
	      Observer oneComObserver = new ShareObserver(C, "Observer2");         			 //tekli firma gözlemci çağırımı. Company C, her iki gözlemcinin de ortak firması
	      
	      int waittime = rd.nextInt(3000); //rastgele 0-3 sn arası seçim yapılıyor, iş parçacıklarını uyutmak için
	      ExecutorService executorService = Executors.newCachedThreadPool();
	      
	      System.out.println("------------------------------------");
	      
	      //A, B , C, D, E firmaları için test çalışması
	      for(int i=0;i<3;i++) {
	    	executorService.execute(new ShareChange(multipleComObserver));  //iş parçacıkları ShareChange sınıfındaki run methodunu kullanır
	    	Thread.sleep(waittime);
	    	
	       }
	      
	      System.out.println("------------------------------------");
	      
	      //tek C firması için test çalışması
	    	for(int j=0;j<2;j++) {
	    		 executorService.execute(new ShareChange(oneComObserver));
	    		 Thread.sleep(waittime);
	    	}
	      }
	     
	   }

