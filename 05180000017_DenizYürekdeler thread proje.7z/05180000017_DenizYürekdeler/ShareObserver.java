import java.io.IOException;
import java.util.ArrayList;


public class ShareObserver extends Observer{
	
	private String observername;
	private Subject subject;
	private ArrayList<Subject> subjectlist;
	
public ShareObserver(Subject subject, String observername) {  //tek firmalı gözlemci
	subjectlist  = new ArrayList<Subject>();
	this.subject=subject;
	attachsubject(subject);  //gözlemciye, gözlenen firma eklenir
	attachobserver(subject); //gözlenen firmaya, gözlemci eklenir
	this.observername=observername;
}

public ShareObserver(ArrayList<Subject> subjects,String observername) {  //çoklu firmali gözlemci
	subjectlist  = new ArrayList<Subject>();
	attachallsubjects(subjects);
	for(Subject s : subjects) { //her bir gözlenen firmaya, gözlemci eklenir
		attachobserver(s);
		this.observername=observername;
	}
}
public void setObserverName(String newname) {
	observername=newname;
}

public String getObserverName() {
	return observername;
}

public void attachsubject(Subject subject){ //gözlenen firmayı, gözlenenler listesine ekleme
	getList().add(subject);
}

public void attachallsubjects(ArrayList<Subject> subjects) {  //attachsubjects methodunu listedeki her bir gözlenen kadar çağıran method
	
	for(Subject s : subjects) {
		attachsubject(s);
	}
}
@Override
public void setSubject(Subject s) {
	subject=s;  //sujecting kullanılabilmesi için 'özel subjecti'( o an üzerinde güncelleme yapılmış) genel subjecte atıyor   (( get subject name methodu için lazım ))
}

public Subject getSubject() {
	return subject;  //global subjecti döndürüyor  (o an hangi subject setlenmiş ise)
}

public void attachobserver(Subject s) {  //gözlenen firmaların, gözlemci listelerine gözlemciyi ekleyen method
	setSubject(s);
	subject.attach(this);
}
@Override
public ArrayList<Subject> getList(){
	return  subjectlist;
}

@Override
public void update() {  //gözlenenlerin durumunu ifade eden method, nofityAll() methodu bunu çağırır
	
	Writer writer = new Writer("sonuclar.txt",true);
	String text =(getSubject().getName() +"'s new change value is = "+ subject.getState() +" Notified by : " +getObserverName());
	
	try {
		writer.write(text);
	} catch (IOException e) {
		e.printStackTrace();
	}
    System.out.println(text); 
}
}
