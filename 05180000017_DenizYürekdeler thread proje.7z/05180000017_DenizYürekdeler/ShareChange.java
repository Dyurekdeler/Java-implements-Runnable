import java.util.ArrayList;
import java.util.Random;

public class ShareChange implements Runnable {
	
	private Observer o;
	private ArrayList<Subject> subjects;
	
	public ShareChange(Observer o) {
		this.o=o;
		this.subjects=o.getList();
	}
	
	Random rd = new Random();
	
@Override
public void run() {
	
	int pick = rd.nextInt(subjects.size());  //gözlemcinin firmalarından bir tanesini rastgele çeker, - eğer tek bir firma varsa onu seçer
	int newshare = rd.nextInt(100)+1;          //firmanın hisse değerini rastgele atar (( not : hisse hiç 0 olmasın diye +1 eklendi ))
	Subject changingcompany = subjects.get(pick);
	changingcompany.setState(newshare);
}
}
