import java.util.ArrayList;

public abstract class Observer {
	   protected Subject subject;
	   public abstract void update(); 
	   public abstract ArrayList<Subject> getList();   //çoklu firma gözlemcisi için bu gereklidir
	   protected abstract void setSubject(Subject subject2);  // subject sadece kalıtımlı sınıflardan setlenebilir.
	
}
